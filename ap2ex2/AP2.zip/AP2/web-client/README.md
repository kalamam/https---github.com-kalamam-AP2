# AP2 - Wazzapp - Web Client

תכנות מתקדם 2 - משה קלמרו ונועם קפלינסקי

## Features
- Support multi-line messages (<kbd>Shift</kbd>+<kbd>Enter</kbd> to insert a new line, <kbd>Enter</kbd> to send)
- Save message drafts when switching between contacts
- Sort contacts by last message date and time
- Show password button
- Unread messages counter

## Installation
```shell
git clone --branch ex2 --single-branch https://github.com/kalamam/AP2.git
cd AP2/web-client
npm install
```

## Running
```shell
npm start
```
Visit http://localhost:3000/

The user that has a message history with 5 other users, and has all the types of messages in it, is `user123`.\
So to sign in to that user, use the password `pass123A`.


All the hardcoded usernames and passwords:
```shell
# format: username:password
user123:pass123A
user456:pass456L
Panda:Pandag4
Koala:Koal653
TheGoat:Messi2023
drake6942:DDdsf5
zuckyhomeboy:Markie1
Harambe:Harambe123
juanTheKing123:password1A
red:notImposter123
joker:Joker123
BenjaminNetanyahu:Bibibi10
```

<br>

**Enjoy!**